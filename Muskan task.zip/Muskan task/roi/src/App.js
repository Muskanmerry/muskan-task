import ROICalculator from './calculator';
import './App.css';

function App() {
  return (
    <div className="App">
     <ROICalculator/>
    </div>
  );
}

export default App;
